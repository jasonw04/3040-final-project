
import kagglehub
import bz2
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.sparse import hstack, csr_matrix
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.utils.class_weight import compute_class_weight
from sklearn.dummy import DummyClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier


from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    ConfusionMatrixDisplay,
    classification_report
)

 
# (3) DATA PREPROCESSING

path = kagglehub.dataset_download("bittlingmayer/amazonreviews")

file_path = path + "/train.ft.txt.bz2"
print("Loading file:", file_path)

with bz2.open(file_path, "rt", encoding="utf-8") as f:
    lines = [line.strip() for line in f]


df = pd.DataFrame(lines, columns=["raw"])

# Extract labels and review text
df["__label__"] = df["raw"].str.extract(r"(__label__\d)")
df["review_text"] = df["raw"].str.replace(r"__label__\d\s+", "", regex=True)

print("\nInitial data shape:", df.shape)
print(df[["__label__", "review_text"]].head())

# Numeric labels
df["label_num"] = df["__label__"].map({"__label__1": 0, "__label__2": 1})

# Keep only what we need
df = df[["review_text", "label_num"]].dropna()
print("\nAfter selecting columns & dropna, shape:", df.shape)

# 🔹 Sample a subset for modelling
sample_size = 200_000
df = df.sample(sample_size, random_state=42)
print(f"\nAfter sampling for modelling (n={sample_size}), shape:", df.shape)

# Clean text
def clean_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

df["clean_text"] = df["review_text"].apply(clean_text)

# Review length (in words) — our extra feature
df["review_length"] = df["clean_text"].str.split().str.len()

print("\nSample cleaned text with length:")
print(df[["clean_text", "review_length"]].head())

 
# Train-test split (text + length + labels together)
 

X_text = df["clean_text"]
X_len = df["review_length"]
y = df["label_num"]

X_train_text, X_test_text, X_train_len, X_test_len, y_train, y_test = train_test_split(
    X_text,
    X_len,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("\nTrain/Test sizes (after sampling):")
print("  X_train_text:", X_train_text.shape)
print("  X_test_text :", X_test_text.shape)

 
# (4) CLASSIFICATION PROBLEM — TF-IDF + review_length + BASELINE
 

vectorizer = TfidfVectorizer(
    stop_words="english",
    max_df=0.95,
    min_df=5,
    ngram_range=(1, 2),
    max_features=20_000
)

# TF–IDF from cleaned text
X_train_tfidf = vectorizer.fit_transform(X_train_text)
X_test_tfidf = vectorizer.transform(X_test_text)

print("\nTF–IDF shapes:")
print("  X_train_tfidf:", X_train_tfidf.shape)
print("  X_test_tfidf :", X_test_tfidf.shape)

# Convert review_length to a sparse column and append to TF–IDF
X_train_len_arr = X_train_len.to_numpy().reshape(-1, 1)
X_test_len_arr = X_test_len.to_numpy().reshape(-1, 1)

X_train_len_sparse = csr_matrix(X_train_len_arr)
X_test_len_sparse = csr_matrix(X_test_len_arr)

# Final feature matrices: [TF–IDF | review_length]
X_train_final = hstack([X_train_tfidf, X_train_len_sparse])
X_test_final = hstack([X_test_tfidf, X_test_len_sparse])

print("\nFinal feature shapes (TF–IDF + review_length):")
print("  X_train_final:", X_train_final.shape)
print("  X_test_final :", X_test_final.shape)

# Class weights
classes = np.unique(y_train)
class_weights = compute_class_weight(
    class_weight="balanced",
    classes=classes,
    y=y_train
)
class_weight_dict = dict(zip(classes, class_weights))
print("\nClass weights:")
print(class_weight_dict)

# Baseline classifier (ignores features, uses label distribution)
baseline = DummyClassifier(strategy="most_frequent")
baseline.fit(X_train_final, y_train)

print("\n=== Baseline (Most Frequent Class) ===")
print(f"Train accuracy = {baseline.score(X_train_final, y_train):.4f}")
print(f"Test accuracy  = {baseline.score(X_test_final, y_test):.4f}")


def evaluate_model(name, model, X_test, y_test, save_confusion=True):
    y_pred = model.predict(X_test)

    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec  = recall_score(y_test, y_pred)
    f1   = f1_score(y_test, y_pred)

    auc = None
    if hasattr(model, "predict_proba"):
        auc = roc_auc_score(y_test, model.predict_proba(X_test)[:, 1])
    elif hasattr(model, "decision_function"):
        auc = roc_auc_score(y_test, model.decision_function(X_test))

    print(f"\n=== {name} ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall   : {rec:.4f}")
    print(f"F1-score : {f1:.4f}")
    print(f"AUC      : {auc:.4f}" if auc is not None else "AUC      : N/A")
    print("\nClassification report:")
    print(classification_report(y_test, y_pred))

    if save_confusion:
        cm = confusion_matrix(y_test, y_pred)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=[0, 1])
        disp.plot(cmap="Blues")
        plt.title(f"Confusion Matrix – {name}")
        plt.grid(False)
        fname = f"cm_{name.replace(' ', '_').lower()}.png"
        plt.savefig(fname, bbox_inches="tight")
        plt.close()
        print(f"Saved confusion matrix as {fname}")

    return acc, prec, rec, f1, auc


results = {}


# KNN

print("\nTraining KNN...")

knn = KNeighborsClassifier(n_neighbors=5, n_jobs=-1)
knn.fit(X_train_final, y_train)

results["KNN"] = evaluate_model("KNN", knn, X_test_final, y_test)

 
# Decision Tree
 
print("\nTraining Decision Tree...")
tree = DecisionTreeClassifier(
    random_state=42,
    max_depth=25,
    min_samples_leaf=20
)
tree.fit(X_train_final, y_train)
results["Decision Tree"] = evaluate_model("Decision Tree", tree, X_test_final, y_test)

 
# Naive Bayes
 
print("\nTraining Naive Bayes...")
nb = MultinomialNB()
nb.fit(X_train_final, y_train)
results["Naive Bayes"] = evaluate_model("Naive Bayes", nb, X_test_final, y_test)

 
# Logistic Regression
 
print("\nTraining Logistic Regression...")
logreg = LogisticRegression(
    max_iter=2000,
    class_weight="balanced",
    n_jobs=-1
)
logreg.fit(X_train_final, y_train)
results["Logistic Regression"] = evaluate_model(
    "Logistic Regression", logreg, X_test_final, y_test
)

import matplotlib.pyplot as plt
import seaborn as sns

# Convert sentiment labels for plotting
df_plot = df.copy()
df_plot["sentiment"] = df_plot["label_num"].map({0: "Negative", 1: "Positive"})

plt.figure(figsize=(8, 5))
sns.boxplot(data=df_plot, x="sentiment", y="review_length", palette="Set2")

plt.title("Review Length by Sentiment")
plt.xlabel("Sentiment")
plt.ylabel("Review Length (Word Count)")
plt.grid(axis="y", linestyle="--", alpha=0.6)

plt.savefig("review_length_by_sentiment.png", dpi=200, bbox_inches="tight")
plt.show()

 
# TOP POSITIVE & NEGATIVE WORDS (from Logistic Regression)
 

# The last feature is review_length; the first N are TF–IDF words.
feature_names = np.array(vectorizer.get_feature_names_out())
word_coefs = logreg.coef_[0][:len(feature_names)]  # ignore last coef (length)

top_positive_indices = np.argsort(word_coefs)[-20:]
top_negative_indices = np.argsort(word_coefs)[:20]

print("\n=== TOP POSITIVE SENTIMENT WORDS (Logistic Regression) ===")
for idx in reversed(top_positive_indices):
    print(f"{feature_names[idx]:<20}  (weight: {word_coefs[idx]:.4f})")

print("\n=== TOP NEGATIVE SENTIMENT WORDS (Logistic Regression) ===")
for idx in top_negative_indices:
    print(f"{feature_names[idx]:<20}  (weight: {word_coefs[idx]:.4f})")


rows = []
for model_name, (acc, prec, rec, f1, auc) in results.items():
    rows.append({
        "Model": model_name,
        "Accuracy": acc,
        "Precision": prec,
        "Recall": rec,
        "F1": f1,
        "AUC": auc
    })

results_df = pd.DataFrame(rows).sort_values(by="Accuracy", ascending=False)

print("\n\n=== SUMMARY OF ALL MODEL RESULTS (sampled 200k, TF–IDF + length) ===")
print(results_df)

results_df.to_csv("model_results_summary_sample200k_with_length_and_knn.csv", index=False)